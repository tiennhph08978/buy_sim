<footer class="pt-4">
	<div class="container-fluid text-center text-md-left bg-dark text-white">
	    <div class="container pt-4">
		    <div class="row text-center">
		      <div class="col-md-12 mt-md-0 mt-3">
		        <h5 class="text-uppercase font-weight-bold">Hệ thống cửa hàng trên toàn quốc</h5>
		        <div class="list-unstyled mt-4">
		        	<li class="mt-2"><i class="fas fa-map-marker-alt"></i> Địa chỉ 95 Hồ Tùng Mậu, Mai Dịch, Cầu Giấy, Hà Nội</li>
					<li class="mt-2">
					<i class="fas fa-phone-square-alt"></i> 081.629.7777
					</li>
		        </div>
		      </div>
		      <!-- <hr class="clearfix w-100 d-md-none pb-3"> -->
		      <!-- <div class="col-md-6 mb-md-0 mb-3">
		        <h5 class="text-uppercase font-weight-bold">Tư vấn, Góp ý</h5>
		        <ul class="list-unstyled mt-3">
		          <li class="mt-2">
		           <i class="fas fa-phone-square-alt"></i> 081.629.7777
		          </li>
		          <li class="mt-2">
		           <i class="fab fa-facebook-messenger"></i> Group Mess
		          </li>
		        </ul>
		      </div> -->
		    </div>
		    <!-- <div class="text-center py-3">
		      <p> BÁN SIM VIET NAM</p>
		    </div> -->
	  	</div>
	</div>
</footer>