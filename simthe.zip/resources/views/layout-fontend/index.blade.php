<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Sim VNN - sim số đẹp">
	<meta name="author" content="Sim VNN">
	<link rel="icon" href="{{asset('icon1.png')}}">
	<title>@yield('title')</title>
	<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> -->
	<link rel="stylesheet" href="{{ asset('font-end/css/bootstrap.css') }}">
	<!-- <link rel="stylesheet" href="../css/bootstrap.min.css"> -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link rel="stylesheet" href="{{ asset('font-end/css/style.css') }}">
	<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
	<script>
		function decialNumber(number){
			return new Intl.NumberFormat('en-US',{style: "decimal", minimumFractionDigits: 0, maximumFractionDigits:2}).format(number);
		}
	</script>
	<style>
		#datatable_filter {
			display: none;
		}
		.dataTables_filter{
			display: none;
		}
		.mt-5{
			margin-top: 6rem !important;
		}
		.dataTables_paginate {
			float:right;
			/* margin: 10px 0 10px 0 ; */
		}
		.paginate_button{
			padding: 10px;
			background:#fff;
			margin:2px;
		}
		/* .page-item.active .page-link {
			z-index: 1;
			color: #fff;
			background-color: #007bff;
			border-color: #007bff;
			} */
			.phone_number {
				font-weight: 700;
				color: #390;
				text-decoration: none;
			}
			.dataTables_paginate {
				cursor: pointer;
			}
		</style>
	</head>
	<body>
		@include('sweetalert::alert', ['cdn' => "https://cdn.jsdelivr.net/npm/_@.com"])
		@include('layout-fontend.nav')
		<!-- content -->
		<div class="container">
			<!-- slider -->
			@include('layout-fontend.slider')

			<!-- end slider -->
			<!-- content -->
			<div class="row">
				@include('layout-fontend.left')
				<div class="col-xl-8 my-2">
					<!-- simviettel -->
					<div class="card">
						<div class="card-body bg-dark">
							<div class="input-group">
								<input type="text" class="form-control"  id="search">
								<div class="input-group-append">
									<button class="btn btn-warning" type="button"><i class="fas fa-search"></i> Tìm kiếm</button>
								</div>
							</div>
							<ul class="list-group mt-3 ml-3">
								<li class="list-item text-white">Tìm sim có số 6789 bạn hãy gõ 6789</li>
								<li class="list-item text-white">Tìm sim có đầu 090</li>
								<li class="list-item text-white">Tìm sim có đuôi 8888 </li>
							</ul>
						</div>
						<div id="search-list"></div>
					</div>
					@yield('content')
				</div>


				@include('layout-fontend.right')
			</div>

			<!-- endcontent -->
		</div>
		<!-- footer -->
		@include('layout-fontend.footer')
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js" integrity="sha512-37T7leoNS06R80c8Ulq7cdCDU5MNQBwlYoy1TX/WUsLFC2eYNqtKlV0QjH7r8JpG/S0GUMZwebnVFLPd6SU5yg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		<script>
			$(document).ready(function(){
				$('#search').on('keyup',function(){
					var query=$(this).val();
					$.ajax({
						url:"search",
						type:'get',
						data:{'search':query},
						success:function(data){
							$('#search-list').html(data);
						}
					});
				})
			})
		</script>

	</body>
	</html>